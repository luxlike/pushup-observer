# 푸시업 옵저버 랜딩 페이지 — 배포 가이드

## 무료 호스팅 비교

| 서비스 | 추천도 | 한국 접속 속도 | 커스텀 도메인 | 빌드 시간 | 특징 |
|---|---|---|---|---|---|
| **GitHub Pages** | ★★★★★ | 보통 (Cloudflare 경유 추천) | 무료 (HTTPS 자동) | 즉시 | git push만으로 배포, 개발자 친화적 |
| **Cloudflare Pages** | ★★★★★ | **매우 빠름** (한국 엣지) | 무료 (HTTPS 자동) | ~30초 | 한국 사용자에게 최고의 속도, 무제한 대역폭 |
| **Netlify** | ★★★★☆ | 보통 | 무료 (HTTPS 자동) | ~30초 | 드래그앤드롭 배포, Form 처리 가능 |
| **Vercel** | ★★★★☆ | 좋음 (서울 리전) | 무료 (HTTPS 자동) | ~20초 | Next.js 친화적, 사이드 프로젝트는 무료 |

---

## 추천: GitHub Pages + Cloudflare (속도 보강)

가장 안정적이고 무료로 영구 사용 가능합니다. App Store 심사 시에도 변하지 않는 URL이 필요한데 GitHub Pages는 가장 신뢰할 수 있는 옵션입니다.

### 1단계 — GitHub 저장소 생성

```bash
cd /path/to/pushup-observer
git init
git add .
git commit -m "Initial landing page"

# GitHub에서 새 public 저장소 생성 후
git remote add origin https://github.com/YOUR_USERNAME/pushup-observer.git
git branch -M main
git push -u origin main
```

저장소 이름을 `YOUR_USERNAME.github.io` 로 만들면 루트 도메인(`https://YOUR_USERNAME.github.io`)을 쓸 수 있고,
다른 이름으로 만들면 서브 경로(`https://YOUR_USERNAME.github.io/pushup-observer`)로 접속됩니다.

### 2단계 — GitHub Pages 활성화

1. 저장소 → **Settings** → **Pages**
2. **Source**: `Deploy from a branch`
3. **Branch**: `main` / `/ (root)`
4. **Save**

1~2분 후 `https://YOUR_USERNAME.github.io/pushup-observer/` 에서 사이트가 살아납니다.

### 3단계 — 커스텀 도메인 (선택)

가비아·후이즈에서 도메인 구입 후 (예: `pushup-observer.com`):

1. 도메인 DNS에 다음 레코드 추가:
   ```
   A    @    185.199.108.153
   A    @    185.199.109.153
   A    @    185.199.110.153
   A    @    185.199.111.153
   CNAME www  YOUR_USERNAME.github.io
   ```
2. 저장소 루트에 `CNAME` 파일 생성, 내용은 `pushup-observer.com`
3. GitHub Pages 설정에서 **Custom domain** 입력 → **Enforce HTTPS** 체크

### 4단계 — Cloudflare로 한국 속도 보강 (선택, 권장)

GitHub Pages는 한국에서 다소 느릴 수 있습니다. Cloudflare를 앞단에 두면 한국 엣지 캐시로 속도가 극적으로 빨라집니다.

1. [cloudflare.com](https://cloudflare.com) 가입 → 사이트 추가
2. 안내에 따라 도메인의 네임서버를 Cloudflare로 변경 (가비아 등에서 설정)
3. Cloudflare DNS에서 위 A 레코드들을 **Proxied (주황색 구름)** 로 설정
4. **SSL/TLS** → `Full` 모드
5. **Speed → Optimization** → Auto Minify (HTML/CSS/JS) 모두 켜기
6. **Caching → Configuration** → Browser Cache TTL: 1 day 이상

이렇게 하면 한국에서 첫 페인트가 100-300ms 수준으로 떨어집니다.

---

## 대안 1: Cloudflare Pages (가장 간단 + 빠름)

GitHub Pages + Cloudflare 조합을 한 번에 해결해 줍니다. **개인적으로는 이 방법을 가장 추천드립니다.**

1. [pages.cloudflare.com](https://pages.cloudflare.com) 가입
2. **Create a project** → **Connect to Git** → GitHub 연결
3. `pushup-observer` 저장소 선택
4. Build settings는 모두 비워둠 (정적 HTML이므로)
5. **Deploy**

자동으로 `pushup-observer.pages.dev` 같은 URL이 발급되고, 한국 엣지에서 직접 서빙됩니다.

`main` 브랜치에 푸시할 때마다 자동 재배포되며, PR 단위로 미리보기 URL도 자동 생성됩니다.

---

## 대안 2: Netlify (드래그앤드롭으로 5초 배포)

git을 쓰기 전에 빠르게 테스트하고 싶을 때:

1. [app.netlify.com/drop](https://app.netlify.com/drop)
2. `pushup-observer` 폴더 전체를 드래그 앤 드롭
3. 즉시 `xxx.netlify.app` URL 발급

이후 `netlify.toml`을 추가하면 git 연동 + 자동 배포로 업그레이드 가능합니다.

---

## 배포 전 체크리스트

App Store 심사 전에 반드시 확인:

- [ ] **개인정보처리방침 페이지 URL** (App Store 필수). `privacy.html` 별도 작성 필요
- [ ] **카메라 권한 사용 사유 설명** (info.plist의 `NSCameraUsageDescription`과 일치)
- [ ] **연락처 이메일** (footer의 `support@example.com`을 실제 이메일로 교체)
- [ ] **App Store 다운로드 링크 교체** (`href="#"` → 실제 App Store URL)
- [ ] **Open Graph 이미지** 추가 (카카오톡·iMessage 공유 시 미리보기)
- [ ] **favicon.ico** 추가
- [ ] **Google Analytics / Plausible** 등 분석 도구 (선택)

---

## OG 이미지 추가 방법

`<head>` 섹션에 다음 추가:

```html
<meta property="og:image" content="https://YOUR_DOMAIN/og-image.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
```

OG 이미지는 1200x630 PNG로 만들어 루트에 `og-image.png`로 저장하시면 됩니다.

---

## 업데이트 방법

내용 수정 후:

```bash
git add .
git commit -m "Update landing page"
git push
```

푸시한 지 1-2분 내 자동 배포됩니다 (GitHub Pages, Cloudflare Pages 모두).

---

## 트러블슈팅

**Q. 이미지가 깨져요**
스크린샷 경로가 `screenshots/01-pushup.png` 형태인지 확인. 대소문자 구분에 주의 (Linux 서버에서 호스팅).

**Q. 한국에서 너무 느려요**
Cloudflare Pages로 옮기시거나, 위에 안내한 Cloudflare 프록시 설정을 적용하세요.

**Q. 폰트가 안 나와요**
Pretendard CDN(`jsdelivr`)이 차단된 환경일 수 있습니다. 폰트를 직접 다운받아 `/fonts` 폴더에 넣고 self-host 하세요.

**Q. App Store 심사에서 사이트 URL을 거부당했어요**
개인정보처리방침이 빠져 있을 가능성이 높습니다. `/privacy.html` 페이지를 추가하고 footer의 "개인정보처리방침" 링크를 연결하세요.
